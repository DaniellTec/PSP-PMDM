package com.ejemplo.E02RestEjemplo.Entities;


import java.math.BigDecimal;
import java.sql.Blob;

import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonbPropertyOrder({
				"id", 
    		     "product_code", 
    		     "product_name", 
    		     "description", 
                     "standard_cost", 
                     "list_price", 
                     "reorder_level", 
                     "target_level", 
                     "quantity_per_unit", 
                     "discontinued", 
                     "minimun_recorder_quantity", 
                     "category",
                     "attachments"
                     
                     })

public class Products {
	
	private Integer id;
	private String product_code;
	private String product_name;
	private String description;
	private BigDecimal standard_cost;
	private BigDecimal list_price;
	private Integer reorder_level;
	private Integer target_level;
	private String quantity_per_unit;
	private Integer discontinued;
	private Integer minimum_reorder_quantity;
	private String category;
	private Blob attachments;
	
	
	
	public Products() {

	}

	public Products(Integer id, String product_code, String product_name, String description, BigDecimal standard_cost, BigDecimal list_price,
			Integer reorder_level, Integer target_level, String quantity_per_unit, Integer discontinued, Integer minimum_reorder_quantity, String category,
			Blob attachments) {
		
		this.id = id;
		this.product_code = product_code;
		this.product_name = product_name;
		this.description = description;
		this.standard_cost = standard_cost;
		this.list_price = list_price;
		this.reorder_level = reorder_level;
		this.target_level = target_level;
		this.quantity_per_unit = quantity_per_unit;
		this.discontinued = discontinued;
		this.minimum_reorder_quantity = minimum_reorder_quantity;
		this.category = category;
		this.attachments = attachments;

	}
	
	
	public void setId(Integer id) 
	
	{
		this.id = id; //
	}

	public Integer getId() 
	
	{
		return id; //
	}

	public void setProductCode(String product_code) 
	
	{
		this.product_code = product_code; //
	}
	
	public String getProductCode() 
	
	{
		return product_code; //
	}

	public void setProductName(String product_name) 
	
	{
		this.product_name = product_name; //
	}

	public String getProductName() 
	
	{
		return product_name; //
	}
	
	public void setDescription(String description) 
	
	{
		this.description = description; //
	}
	
	public String getDescription() 
	
	{
		return description; //
	}

	public void setStandardCost(BigDecimal standard_cost) 
	
	{
		this.standard_cost = standard_cost; //
	}
	
	public BigDecimal getStandardCost() 
	
	{
		return standard_cost; //
	}

	public void setListPrice(BigDecimal list_price) 
	
	{
		this.list_price = list_price; //
	}

	public BigDecimal getListPrice() 
	
	{
		return list_price; //
	}

	public void setReorderLevel(Integer reorder_level) 
	
	{
		this.reorder_level = reorder_level; //
	}

	public Integer getReorderLevel() 
	
	{
		return reorder_level; //
	}

	public void setTargetLevel(Integer target_level)
	
	{
		this.target_level = target_level; //
	}

	public Integer getTargetLevel() 
	
	{
		return target_level; //
	}

	public void setQuantityPerUnit(String quantity_per_unit) 
	
	{
		this.quantity_per_unit = quantity_per_unit; //
	} 

	public String getQuantityPerUnit()
	
	{
		return quantity_per_unit; //
	}

	public void setDiscontinued(Integer discontinued) 
	
	{
		this.discontinued = discontinued; //
	}

	public Integer getDiscontinued() 
	
	{
		return discontinued; //
	}

	public void setMinimumReorderQuantity(Integer minimum_reorder_quantity)
	
	{
		this.minimum_reorder_quantity = minimum_reorder_quantity; //
	}

	public Integer getMinimumReorderQuantity() 
	
	{
		return minimum_reorder_quantity; //
	}

	public void setCategory(String category)
	
	{
		this.category = category; //
	}

	public String getCategory() 
	
	{
		return category; //
	}
	
	public void setAttachments(Blob Attachments)
	
	{
		this.attachments = Attachments; //
	}

	public Blob getAttachments() 
	
	{
		return attachments; //
	}



	@Override
	public String toString() 
	
	{
		return "Products [" + (id != null ? "id=" + id + ", " : "")
				+ (product_code != null ? "product_code=" + product_code + ", " : "")
				+ (product_name != null ? "product_name=" + product_name + ", " : "")
				+ (description != null ? "description=" + description + ", " : "")
				+ (list_price != null ? "list_price=" + list_price + ", " : "")
				+ (reorder_level != null ? "reorder_level=" + reorder_level + ", " : "")
				+ (target_level != null ? "target_level=" + target_level + ", " : "")
				+ (quantity_per_unit != null ? "quantity_per_unit=" + quantity_per_unit : "")
				+ (discontinued != null ? "discontinued=" + discontinued : "") 
				+ (minimum_reorder_quantity != null ? "minimum_reorder_quantity=" + minimum_reorder_quantity : "")
				+ (category != null ? "category=" + category : "")
				+ (attachments != null ? "attachments=" + attachments : "")
				+ "]";
	}

}



