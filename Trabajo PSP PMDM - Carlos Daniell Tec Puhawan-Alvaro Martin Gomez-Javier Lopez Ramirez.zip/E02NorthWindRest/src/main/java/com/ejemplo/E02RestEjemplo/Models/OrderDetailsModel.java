package com.ejemplo.E02RestEjemplo.Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sql.DataSource;

import com.ejemplo.E02RestEjemplo.DBFactory.DBFactory;
import com.ejemplo.E02RestEjemplo.Entities.OrderDetails;



public class OrderDetailsModel {
    
    Connection conexion = null;

    public OrderDetailsModel() throws SQLException {
	DataSource ds = DBFactory.getMySQLDataSource();
	conexion = ds.getConnection();
    }

    public OrderDetails read(Integer id) {
    OrderDetails detallespedido = null;
	Statement sentencia = null;
	
	String sql =  "SELECT * "
			+"FROM order_details "
			+ "WHERE id = " + id;

	try {
	    sentencia = conexion.createStatement();
	    ResultSet rs = sentencia.executeQuery(sql);
	    while (rs.next()) { // Si hay un cliente que existe
	    	detallespedido = new OrderDetails(
	    			rs.getInt("id"),
	    			rs.getInt("order_id"),
	    			rs.getInt("product_id"),
	    			rs.getBigDecimal("quantity"),
	    			rs.getBigDecimal("unit_price"),
	    			rs.getDouble("discount"),
	    			rs.getInt("status_id"),
	    			rs.getDate("date_allocated"),
	    			rs.getInt("purchase_order_id"),
	    			rs.getInt("inventory_id")
	    			
			);
	    };
	    
	} catch (SQLException e) {
	    System.err.println("Error en read de Detalles de Detallespedido: " + e.getMessage());
	    return null;
	}

	return detallespedido;
    }

    /**
     * 
     * @param cliente
     * @return Devuelve el id del registro recien insertado
     */
    public Integer insert(OrderDetails detallespedido) throws  SQLException {
	Integer id = null;
	PreparedStatement ps = null;
	String sql = "INSERT INTO order_details ( "
		+ "`id`,"
		+ " `order_id`,"
		+ " `product_id`,"
		+ "`quantity`,"
		+ " `unit_price`,"
		+ " `discount` ,"
		+ " `status_id`,"
		+ "`date_allocated`,"
		+ " `purchase_order_id`,"
		+ " `inventory_id`"
		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	try {
	    ps = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	    
	    ps.setBigDecimal(1, detallespedido.getQuantity());
	    ps.setBigDecimal(2, detallespedido.getUnitPrice());
	    ps.setDate(3, detallespedido.getDateAllocated());
	    ps.setDouble(4,detallespedido.getDiscount());
	   
	    ps.setInt(5, detallespedido.getId());
	    ps.setInt(6, detallespedido.getOrderId());
	    ps.setInt(7, detallespedido.getProductId());
	    ps.setInt(8, detallespedido.getStatusId());
	    ps.setInt(9, detallespedido.getPurcharseOrderId());
	    ps.setInt(10, detallespedido.getInventoryId());
	    
	    if (ps.executeUpdate() > 0) {
		ResultSet rs = ps.getGeneratedKeys();
		if (rs.next()) {
		    id = rs.getInt(1);
		}
	    }

	} catch (SQLException e) {
	    System.err.println("Error al insertar order_details: " + e.getMessage());
	    throw e;
	}

	return id;
    }

    public Boolean delete(Integer iddetallespedido) throws SQLException {
	Boolean resultado = false;

	PreparedStatement ps = null;
	String sql = "DELETE FROM order_details where id = ?";
	try {
	    ps = conexion.prepareStatement(sql);

	    ps.setInt(1, iddetallespedido);

	    resultado = (ps.executeUpdate() > 0);

	} catch (SQLException e) {
	    System.err.println("Error al borrar DetallesPedidos: " + e.getMessage());
	    throw e;
	}

	return resultado;
    }

    public Boolean update(OrderDetails detallespedido) throws SQLException  {
	Boolean resultado = false;

	PreparedStatement ps = null;
	String sql = "UPDATE order_details set "
		+ "id = ?, "
		+ "order_id = ?, "
		+ "product_id = ?, "
		+ "quantity = ?, "
		+ "unit_price = ?, "
		+ "discount  = ?, "
		+ "status_id = ?, "
		+ "date_allocated = ?, "
		+ "purchase_order_id = ?, "
		+ "inventory_id = ? "
		+ "where id = ?";
	try {
	    ps = conexion.prepareStatement(sql);
	   
	    ps.setBigDecimal(1, detallespedido.getQuantity());
	    ps.setBigDecimal(2, detallespedido.getUnitPrice());
	    ps.setDate(3, detallespedido.getDateAllocated());
	    ps.setDouble(4,detallespedido.getDiscount());
		   
	    ps.setInt(5, detallespedido.getId());
	    ps.setInt(6, detallespedido.getOrderId());
	    ps.setInt(7, detallespedido.getProductId());
	    ps.setInt(8, detallespedido.getStatusId());
	    ps.setInt(9, detallespedido.getPurcharseOrderId());
	    ps.setInt(10, detallespedido.getInventoryId());
	    
	    resultado = (ps.executeUpdate() > 0);

	} catch (SQLException e) {
	    System.err.println("Error al actualizar DetallesPedido: " + e.getMessage());
	    throw e;
	}

	return resultado;
    }

    public ArrayList<OrderDetails> lista(String filtro, Integer limite, Integer offset)

    {
	ArrayList<OrderDetails> detallespedidos = new ArrayList<OrderDetails>();
	Statement sentencia = null;

	String sql = "SELECT `id`, "
		+ "`order_id`, "
		+ "`product_id`, "
		+ "`quantity`, "
		+ "`unit_price`, "
		+ "`discount`, "
		+ "`status_id` , "
		+ "`date_allocated`,"
		+ "`purchase_order_id`, "
		+ "`inventory_id` "
		+ "FROM order_details ";

	try {
	    if (filtro != null)
		sql += " WHERE " + filtro;
	    if (limite != null)
		sql += " LIMIT " + limite;
	    if (offset != null)
		sql += " OFFSET " + offset;
	    sentencia = conexion.createStatement();
	    ResultSet rs = sentencia.executeQuery(sql);
	    while (rs.next()) { // Si todavía hay un cliente lo añado al array
	    detallespedidos.add(new OrderDetails(
	    		rs.getInt("id"),
				rs.getInt("order_id"),
				rs.getInt("product_id"),
				rs.getBigDecimal("quantity"),
				rs.getBigDecimal("unit_price"),
				rs.getDouble("discount"),
				rs.getInt("status_id"),
				rs.getDate("date_allocated"),
				rs.getInt("purchase_order_id"),
				rs.getInt("inventory_id")
				
	    		));
	    };
	} catch (SQLException e) {
	    System.err.println("Error en read de DetallesPedidos: " + e.getMessage());
	    return null;
	}

	return detallespedidos;
    }

}
