package com.ejemplo.E02RestEjemplo.Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sql.DataSource;

import com.ejemplo.E02RestEjemplo.DBFactory.DBFactory;
import com.ejemplo.E02RestEjemplo.Entities.Products;



public class ProductsModel {
    
    Connection conexion = null;

    public ProductsModel() throws SQLException {
	DataSource ds = DBFactory.getMySQLDataSource();
	conexion = ds.getConnection();
    }

    public Products read(Integer id) {
	Products producto = null;
	Statement sentencia = null;

	String sql = "SELECT `id`, "
			+ "`product_code`, "
			+ "`product_name`, "
			+ "`description`, "
			+ "`standard_cost`, "
			+ "`list_price`, "
			+ "`reorder_level` , `target_level`,"
		+ "`quantity_per_unit`, `discontinued`, `minimum_reorder_quantity`, `category`, `attachments` "
		+ "FROM products "
		+ "WHERE id = " + id;

	try {
	    sentencia = conexion.createStatement();
	    ResultSet rs = sentencia.executeQuery(sql);
	    while (rs.next()) { // Si hay un cliente que existe
		producto = new Products(
			rs.getInt("id"),
			rs.getString("product_code"),
			rs.getString("product_name"),
			rs.getString("description"),
			rs.getBigDecimal("standard_cost"),
			rs.getBigDecimal("list_price"),
			rs.getInt("reorder_level"),
			rs.getInt("target_level"),
			rs.getString("quantity_per_unit"),
			rs.getInt("discontinued"),
			rs.getInt("minimum_reorder_quantity"),
			rs.getString("category"),
			rs.getBlob("attachments"));
	    };
	    
	} catch (SQLException e) {
	    System.err.println("Error en read de Productos: " + e.getMessage());
	    return null;
	}

	return producto;
    }

    /**
     * 
     * @param cliente
     * @return Devuelve el id del registro recien insertado
     */
    public Integer insert(Products producto) throws  SQLException {
	Integer id = null;
	PreparedStatement ps = null;
	String sql = "INSERT INTO products ( "
		+ "`supplier_ids`, `id`, `product_code`, `product_name`, "
		+ "`description`, `standard_cost`, `list_price` , `reorder_level`,"
		+ "`target_level`, `quantity_per_unit`, `discontinued`, `minimum_reorder_quantity`, `category`, "
		+ "`attachments`) "
		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	try {
	    ps = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	 
	    
	    if ( producto.getProductCode() == null)
        {
            ps.setNull(1, 0);
        }
        else
        {
            ps.setString(1, producto.getProductCode());
        }
	    
	    if ( producto.getProductName() == null)
        {
            ps.setNull(2, 0);
        }
        else
        {
            ps.setString(2, producto.getProductName());
        }
	    
	    if ( producto.getDescription() == null)
        {
            ps.setNull(3, 0);
        }
        else
        {
            ps.setString(3, producto.getDescription());
        }
	    
	    if ( producto.getStandardCost() == null)
        {
            ps.setNull(4, 0);
        }
        else
        {
            ps.setBigDecimal(4, producto.getStandardCost());
        }
	    
	    if ( producto.getListPrice() == null)
        {
            ps.setNull(5, 0);
        }
        else
        {
            ps.setBigDecimal(5, producto.getListPrice());
        }
	    
	    if ( producto.getReorderLevel() == null)
        {
            ps.setNull(6, 0);
        }
        else
        {
            ps.setInt(6, producto.getReorderLevel());
        }
	    
	    if ( producto.getTargetLevel() == null)
        {
            ps.setNull(7, 0);
        }
        else
        {
            ps.setInt(7, producto.getTargetLevel());
        }
	    
	    if ( producto.getQuantityPerUnit() == null)
        {
            ps.setNull(8, 0);
        }
        else
        {
            ps.setString(8, producto.getQuantityPerUnit());
        }
	    
	    if ( producto.getDiscontinued() == null)
        {
            ps.setNull(9, 0);
        }
        else
        {
            ps.setInt(9, producto.getDiscontinued());
        }
	    
	    if ( producto.getMinimumReorderQuantity() == null)
        {
            ps.setNull(10, 0);
        }
        else
        {
            ps.setInt(10, producto.getMinimumReorderQuantity());
        }
	   
	    if ( producto.getCategory() == null)
        {
            ps.setNull(11, 0);
        }
        else
        {
            ps.setString(11, producto.getCategory());
        }
	    
	    if ( producto.getAttachments() == null)
        {
            ps.setNull(12, 0);
        }
        else
        {
            ps.setBlob(12, producto.getAttachments());
        }
	    
	    if (ps.executeUpdate() > 0) {
		ResultSet rs = ps.getGeneratedKeys();
		if (rs.next()) {
		    id = rs.getInt(1);
		}
	    }

	} catch (SQLException e) {
	    System.err.println("Error al insertar Products: " + e.getMessage());
	    throw e;
	}

	return id;
    }

    public Boolean delete(Integer idproducto) throws SQLException {
	Boolean resultado = false;

	PreparedStatement ps = null;
	String sql = "DELETE FROM products where id = ?";
	try {
	    ps = conexion.prepareStatement(sql);

	    ps.setInt(1, idproducto);

	    resultado = (ps.executeUpdate() > 0);

	} catch (SQLException e) {
	    System.err.println("Error al borrar Productos: " + e.getMessage());
	    throw e;
	}

	return resultado;
    }

    public Boolean update(Products producto) throws SQLException  {
	Boolean resultado = false;

	PreparedStatement ps = null;
	String sql = "UPDATE products set "
		+ "id = ?, "
		+ "product_code = ?, "
		+ "product_name = ?, "
		+ "description = ?, "
		+ "standard_cost = ?, "
		+ "list_price  = ?, "
		+ "reorder_level = ?, "
		+ "target_level = ?, "
		+ "quantity_per_unit = ?, "
		+ "discontinued = ?, "
		+ "minimum_reorder_quantity = ?, "
		+ "attachments = ?, "
		+ "where id = ?";
	try {
	    ps = conexion.prepareStatement(sql);
	   
	    ps.setString(1, producto.getProductCode());
	    ps.setString(2, producto.getProductName());
	    ps.setString(3, producto.getDescription());
	    ps.setBigDecimal(4, producto.getStandardCost());
	    ps.setBigDecimal(5, producto.getListPrice());
	    ps.setInt(6, producto.getReorderLevel());
	    ps.setInt(7, producto.getTargetLevel());
	    ps.setString(8, producto.getQuantityPerUnit());
	    ps.setInt(9, producto.getDiscontinued());
	    ps.setInt(10, producto.getMinimumReorderQuantity());
	    ps.setString(11, producto.getCategory());
	    ps.setBlob(12, producto.getAttachments());
	    ps.setInt(13, producto.getId());
	    
	    resultado = (ps.executeUpdate() > 0);

	} catch (SQLException e) {
	    System.err.println("Error al actualizar Producto: " + e.getMessage());
	    throw e;
	}

	return resultado;
    }

    public ArrayList<Products> lista(String filtro, Integer limite, Integer offset)

    {
	ArrayList<Products> productos = new ArrayList<Products>();
	Statement sentencia = null;

	String sql = "SELECT `id`, "
		+ "`product_code`, "
		+ "`product_name`, "
		+ "`description`, "
		+ "`standard_cost`, "
		+ "`list_price`, "
		+ "`reorder_level` , "
		+ "`target_level`,"
		+ "`quantity_per_unit`, "
		+ "`discontinued`, "
		+ "`minimum_reorder_quantity`, "
		+ "`category`, "
		+ "`attachments` " 
		+ "FROM products ";

	try {
	    if (filtro != null)
		sql += " WHERE " + filtro;
	    if (limite != null)
		sql += " LIMIT " + limite;
	    if (offset != null)
		sql += " OFFSET " + offset;
	    sentencia = conexion.createStatement();
	    ResultSet rs = sentencia.executeQuery(sql);
	    while (rs.next()) { // Si todavía hay un cliente lo añado al array
		productos.add(new Products(
				//rs.getString("supplier_ids"),
				rs.getInt("id"),
				rs.getString("product_code"),
				rs.getString("product_name"),
				rs.getString("description"),
				rs.getBigDecimal("standard_cost"),
				rs.getBigDecimal("list_price"),
				rs.getInt("reorder_level"),
				rs.getInt("target_level"),
				rs.getString("quantity_per_unit"),
				rs.getInt("discontinued"),
				rs.getInt("minimum_reorder_quantity"),
				rs.getString("category"),
				rs.getBlob("attachments")));
	    };
	} catch (SQLException e) {
	    System.err.println("Error en read de Productos: " + e.getMessage());
	    return null;
	}

	return productos;
    }

}
